<!-- <a href="#" class="share share-fb"><i class="fa fa-facebook"></i></a>
<a href="#" class="share share-tw"><i class="fa fa-twitter"></i></a>
<a href="#" class="share share-pi"><i class="fa fa-pinterest"></i></a>
<a href="#" class="share share-en"><i class="fa fa-envelope"></i></a> -->
<?php naked_social_share_buttons(); ?>