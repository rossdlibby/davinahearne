<div class="header-opt-in single container home-opt-in">
	<div class="col-md-4 text-center capitalized small">
		<div class="row">
			<div class="col-md-6 col-md-offset-6">
				<p><strong>Get weekly goodies, inspiration + updates straight to your inbox</strong></p>
			</div>
		</div>
	</div>
	<div class="col-md-8">
		<div class="row">
			<form class="form-horizontal" action="http://www.aweber.com/scripts/addlead.pl" method="post">
				<div class="col-md-3">
					<input type="text" name="name" placeholder="Enter your name" class="form-control not-rounded no-border border-bottom" />
				</div>
				<div class="col-md-3">
					<input type="email" name="email" placeholder="Enter your email" class="form-control not-rounded no-border border-bottom" />
				</div>
				<div class="col-md-1">
					<input type="submit" value="Give it to me" class="btn btn-primary" />
				</div>
			</form>
		</div>
	</div>
</div>